## Запуск

1. Откройте проект в Xcode 15+.
2. Установите пакеты (SPM): FirebaseCore, FirebaseAuth, GoogleSignIn.
3. Добавьте `GoogleService-Info.plist` в таргет приложения.
4. В Target → Info → URL Types добавьте reversed CLIENT_ID из `GoogleService-Info.plist`.
5. Запустите на симуляторе/устройстве. Google-вход должен работать сразу (после корректного plist и URL scheme).

Примечание: экран «Добро пожаловать» показывается после успешного обмена Firebase idToken на accessToken у backend. Если сети нет — переход временно отключён (или включите оффлайн-фолбэк в `AppState`).

## Firebase: что настроить

- Пакеты: FirebaseCore, FirebaseAuth, GoogleSignIn.
- Файл `GoogleService-Info.plist` (iOS) в таргете.
- Инициализация в `App/TestAppRoshanovDias.swift`: `FirebaseApp.configure()` и `GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: ...)` берётся из Firebase.
- URL scheme: Target → Info → URL Types → добавьте reversed CLIENT_ID.

### Apple Sign In (важно)
- В Xcode: Target → Signing & Capabilities → добавьте “Sign in with Apple”.
- В Apple Developer Console: создайте App ID (ваш Bundle ID) и включите для него “Sign In with Apple”.
- Пересоберите профиль подписи / включите Automatically manage signing.

Простыми словами: без платной подписки Apple Developer и без созданного App ID в консоли — вход через Apple работать не будет. Это ограничение самой Apple, тут «галочкой в Xcode» не обойти.

## Backend API (JSON‑RPC 2.0)

POST `https://api.court360.ai/rpc/client`

Тело запроса:
```json
{
  "jsonrpc": "2.0",
  "method": "auth.firebaseLogin",
  "params": { "fbIdToken": "<Firebase_idToken>" },
  "id": 1
}
```
Ответ:
```json
{
  "jsonrpc": "2.0",
  "result": { "accessToken": "xxx", "me": { "id": 1, "name": "John Doe" } },
  "id": 1
}
```

## Архитектура (MVVM)
- `AppState` — корневой ViewModel: состояние авторизации, пользователь, ошибки, вызовы сервисов.
- `AuthViewModel`, `WelcomeViewModel` — view-специфичные модели.
- `Services/Services.swift`:
  - `FirebaseAuthService` — вход через Apple/Google → получение реального Firebase idToken.
  - `CourtAPIClient` — JSON‑RPC клиент (`auth.firebaseLogin`).
  - `KeychainTokenStore` — безопасное хранение accessToken.
- `LoginView`, `WelcomeView`, `TabBarView` — представления; переключение в `ContentView` по `isAuthenticated`.

## Обработка ошибок
- Ошибки авторизации/сети показываются в UI через `errorMessage`.
- Поток Google/Apple исполняется на главном потоке (важно для UI API).
- Для отладки добавлены простые `print`‑логи.

## Что улучшить для продакшена
- Локализация и человеко‑читаемые сообщения об ошибках.
- Рефреш токенов, авто‑продление сессии.
- Улучшенные политики Keychain (доступ по биометрии, работа с группами доступов).
- Телеметрия/логирование (без персональных данных), фича‑флаги.
- Юнит/снэпшот тесты для `APIClient`, `TokenStore`, потоков в `AppState`.

## Структура проекта
- `App/` — точка входа, контейнеры, `ContentView`.
- `Model/` — модели (`UserProfile`, `AuthLoginResult`).
- `Services/` — API клиент, хранилище токена, Firebase‑сервис.
- `ViewModel/` — `AuthViewModel`, `WelcomeViewModel`.
- `View/` — `LoginView`, `WelcomeView`, `TabBarView`.

