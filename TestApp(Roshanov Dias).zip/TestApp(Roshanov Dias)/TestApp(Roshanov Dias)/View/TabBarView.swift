import SwiftUI

struct TabBarView: View {
    @EnvironmentObject var appState: AppState
    @State private var selection: Int = 0
    
    var body: some View {
        TabView(selection: $selection) {
            WelcomeView(viewModel: WelcomeViewModel(appState: appState))
                .tabItem { Label("Gifts", systemImage: "gift") }
                .tag(0)
            
            Text("Gifts 2")
                .tabItem { Label("Gifts", systemImage: "leaf") }
                .tag(1)
            
            Text("Events")
                .tabItem { Label("Events", systemImage: "calendar") }
                .tag(2)
            
            Text("Cart")
                .tabItem { Label("Cart", systemImage: "cart") }
                .tag(3)
            
            Text("Profile")
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
                .tag(4)
        }
        .toolbar(.hidden, for: .tabBar)
        .safeAreaInset(edge: .bottom) {
            HStack {
                tabItem(icon: "gift", title: "Gifts", index: 0)
                tabItem(icon: "leaf", title: "Gifts", index: 1)
                tabItem(icon: "calendar", title: "Events", index: 2)
                tabItem(icon: "cart", title: "Cart", index: 3)
                tabItem(icon: "person.crop.circle", title: "Profile", index: 4)
            }
            .padding(.horizontal, 40)
            .padding(.vertical, 24)
            .frame(maxWidth: .infinity)
            .background(Color.white)
        }
    }
    
    @ViewBuilder
    private func tabItem(icon: String, title: String, index: Int) -> some View {
        Button {
            selection = index
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .frame(width: 48, height: 49)
                    .foregroundStyle(selection == index ? .black : .gray)
                Text(title)
                    .font(.caption)
                    .foregroundStyle(selection == index ? .black : .gray)
            }
            .frame(maxWidth: .infinity)
        }
    }
}

#Preview {
    TabBarView().environmentObject(AppState())
}
