//
//  LoginView.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import SwiftUI
import AuthenticationServices

struct LoginView: View {
    @ObservedObject var viewModel: AuthViewModel

    var body: some View {
        ZStack {
            Color("backgroundColor").edgesIgnoringSafeArea(.all)
            Image("vector")
                .resizable()
                .scaledToFit()
                .frame(width: 597,height: 537)
                .offset(x:0,y:50)
            Image("rose")
                .resizable()
                .scaledToFit()
                .frame(width: 171,height: 285)
            VStack{
                HStack {
                    Spacer()
                    Button("Skip") {}
                        .font(.system(size:17))
                        .foregroundStyle(Color.black)
                        .padding(.trailing,16)
                }.frame(width: 390, height: 44)
                VStack(alignment: .leading) {
                    Image("welcome")
                        .padding(.leading,16)
                    Text("Enter your phone number. We will send you an SMS\nwith a confirmation code to this number.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(.top,20)
                        .padding(.leading,16)
                    Spacer()
                }
                .frame(maxWidth: 390,maxHeight: 336, alignment: .leading)
                Spacer()
                Group{
                    VStack(spacing: 8) {
                        Button(action: {
                            print("[UI] Apple button tapped")
                            viewModel.signInWithApple()
                        }) {
                            HStack(spacing: 8) {
                                Image("apple")
                                    .font(.title2)
                                Text("Continue with Apple")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundStyle(.black)
                            }
                            .foregroundStyle(.primary)
                            .frame(maxWidth: 362)
                            .frame(height: 56)
                            .background(.white)
                            .cornerRadius(10)
                        }
                        Button(action: {
                            print("[UI] Google button tapped")
                            viewModel.signInWithGoogle()
                        }) {
                            HStack(spacing: 8) {
                                Image("google")
                                    .font(.title2)
                                Text("Continue with Google")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundStyle(.black)
                            }
                            .foregroundStyle(.primary)
                            .frame(maxWidth: 362)
                            .frame(height: 56)
                            .background(.white)
                            .cornerRadius(10)
                        }
                        
                    }
                    VStack(spacing: 4) {
                        Text("By continuing, you agree to Assetsy’s")
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)
                        HStack(spacing: 4) {
                            Button("Terms of Use") {}
                                .font(.system(size: 11))
                            Text("and")
                                .font(.system(size: 11))
                                .foregroundStyle(.secondary)
                            Button("Privacy Policy") {}
                                .font(.footnote)
                        }
                    }
                    .padding(.bottom,86)
                }
                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundStyle(.red)
                        .font(.footnote)
                        .multilineTextAlignment(.center)
                        .padding(.top, 8)
                }
                if viewModel.isLoading {
                    ProgressView().padding(.top, 8)
                }
            }
        }
    }
}

#Preview {
    let appState = AppState()
    let vm = AuthViewModel(appState: appState)
    return LoginView(viewModel: vm)
}
