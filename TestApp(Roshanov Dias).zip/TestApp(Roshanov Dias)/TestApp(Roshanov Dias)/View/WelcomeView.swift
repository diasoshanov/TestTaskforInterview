//
//  WelcomeView.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import SwiftUI

struct WelcomeView: View {
    @ObservedObject var viewModel: WelcomeViewModel
    @State var textField = ""
    
    private let items = [
        "events",
        "events",
        "events",
        "events"
    ]

    var body: some View {
        ZStack {
            Color("backgroundColor").ignoresSafeArea()
            VStack{
                HStack {
                    Spacer()
                    Text("Deliver to")
                        .font(.system(size:17))
                        .foregroundStyle(Color.black)
                    Image("flag")
                    Text("USD")
                    Image(systemName:"chevron.down")
                }.frame(width: 390, height: 44)
                    .padding(.trailing,25)
                HStack {
                    Image("gifts").padding(.leading,16)
                    Spacer()
                    HStack{
                        TextField("",text: $textField)
                            .frame(width: 110, height:42)
                            .background(Color.white)
                            .cornerRadius(16)
                            .overlay {
                                HStack{
                                    Image(systemName: "magnifyingglass")
                                        .padding(.leading,8)
                                        .foregroundStyle(.secondary)
                                    Text("Search")
                                        .foregroundStyle(.secondary)
                                    Spacer()
                                }
                            }
                    }.padding(.trailing,25)
                }
                .padding(.top, 8)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                            RoundedRectangle(cornerRadius: 16)
                                .fill(Color.white)
                                .frame(width: 374, height: 150)
                                .overlay(
                                    HStack {
                                        Image(item)
                                        Spacer()
                                    }
                                )
                        }
                    }
                    .padding(.horizontal, 16)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                            VStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.white)
                                    .frame(width: 80, height: 80)
                                Text("test")
                            }
                        }
                        Button(action: {}) {
                            Text("Show all")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .foregroundStyle(Color.white)
                    ScrollView(showsIndicators: true) {
                        Button(action: {}) {
                            Text("View all categories")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                                .frame(height: 32)
                                .background(Color.white)
                                .overlay(
                                    Capsule().stroke(Color.black, lineWidth: 1)
                                )
                                .clipShape(Capsule())
                        }.padding(.vertical)
                        HStack{
                            ForEach(0..<3) { _ in
                                Button(action: {}) {
                                    HStack {
                                        Text("Popular")
                                            .font(.system(size: 14, weight: .semibold))
                                            .foregroundColor(.black)
                                            .frame(height: 32)
                                        Image(systemName:"chevron.down")
                                            .foregroundStyle(Color.black)
                                    }.padding(.horizontal)
                                    .background(Color("backgroundColor"))
                                    .cornerRadius(16)
                                }
                            }
                        }.padding(.horizontal)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            ForEach(0..<20) { _ in
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color(.systemGray6))
                                    .frame(height: 180)
                            }
                        }
                        .padding(16)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .padding(.horizontal, 16)
                .padding(.top, 16)
            }
        }
    }
}

#Preview {
    let appState = AppState()
    appState.currentUser = UserProfile(id: 1, name: "John Doe")
    let vm = WelcomeViewModel(appState: appState)
    return WelcomeView(viewModel: vm)
}
