//
//  WelcomeView.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import SwiftUI

struct WelcomeView: View {
    @ObservedObject var viewModel: WelcomeViewModel
    @State var textField = ""
    
    var body: some View {
        ZStack {
            Color("backgroundColor").ignoresSafeArea()
            VStack{
                HStack {
                    Spacer()
                    Text("Deliver to")
                        .font(.system(size:17))
                        .foregroundStyle(Color.black)
                    Image("flag")
                    Text("USD")
                    Image(systemName:"chevron.down")
                }.frame(width: 390, height: 44)
                    .padding(.trailing,19)
                HStack {
                    Image("gifts")
                    Spacer()
                    TextField("",text: $textField)
                        .frame(width: 110, height:42)
                        .background(Color.white)
                        .cornerRadius(16)
                        .overlay {
                            HStack{
                                Image(systemName: "magnifyingglass")
                                    .padding(.leading,8)
                                    .foregroundStyle(.secondary)
                                Text("Search")
                                    .foregroundStyle(.secondary)
                                Spacer()
                            }
                        }
                }
                .padding(.top, 12)
                .padding(.leading,16)
                .padding(.trailing,25)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Array(viewModel.items.enumerated()), id: \.offset) { index, item in
                            Image(item)
                                .resizable()
                                .frame(width: 374, height: 150)
                        }
                    }.padding(.leading, 16)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(Array(viewModel.image.enumerated()), id: \.offset) { index, item in
                            VStack {
                                Image(item.image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 80, height: 80)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                                Text(item.name)
                                    .font(.system(size: 12))
                                    .frame(maxWidth: 80, maxHeight: 32)
                            }
                        }
                        Button(action: {}) {
                            Text("Show all")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                        }
                    }.padding(.leading,16)
                }
                ZStack {
                    RoundedRectangle(cornerRadius: 16)
                        .foregroundStyle(Color.white)
                    ScrollView(showsIndicators: true) {
                        VStack(spacing: 16){
                            Button(action: {}) {
                                Text("View all categories")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.black)
                                    .padding(.horizontal, 16)
                                    .frame(height: 32)
                                    .background(Color.white)
                                    .overlay(
                                        Capsule().stroke(Color.black, lineWidth: 1)
                                    )
                                    .clipShape(Capsule())
                            }.padding(.top,16)
                            HStack{
                                ForEach(0..<3) { _ in
                                    Button(action: {}) {
                                        HStack {
                                            Text("Popular")
                                                .font(.system(size: 14, weight: .semibold))
                                                .foregroundColor(.black)
                                                .frame(height: 32)
                                            Image(systemName:"chevron.down")
                                                .foregroundStyle(Color.black)
                                        }.padding(.horizontal)
                                            .background(Color("backgroundColor"))
                                            .cornerRadius(16)
                                    }
                                }
                            }.padding(.bottom)
                        }.padding(.horizontal)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 6) {
                            ForEach(Array(viewModel.gridImg.enumerated()), id: \.offset) {_, item in
                                Image(item)
                                    .resizable()
                                    .frame(width: 156, height: 156)
                            }
                        }.frame(width: 318)
                    }
                }
                .frame(maxWidth: 350, maxHeight: .infinity, alignment: .top)
            }
        }
    }
}

#Preview {
    let appState = AppState()
    appState.currentUser = UserProfile(id: 1, name: "John Doe")
    let vm = WelcomeViewModel(appState: appState)
    return WelcomeView(viewModel: vm)
}
