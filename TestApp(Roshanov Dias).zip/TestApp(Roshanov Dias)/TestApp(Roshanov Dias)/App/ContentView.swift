//
//  ContentView.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appState: AppState
    var body: some View {
        Group {
            if appState.isAuthenticated {
                TabBarView()
            } else {
                LoginView(viewModel: AuthViewModel(appState: appState))
            }
        }
    }
}

#Preview {
    ContentView().environmentObject(AppState())
}
