//
//  AppState.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import Foundation
import SwiftUI

final class AppState: ObservableObject {
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var accessToken: String? {
        didSet { isAuthenticated = accessToken != nil }
    }
    @Published var isAuthenticated: Bool = false
    @Published var currentUser: UserProfile?

    private let tokenStore: TokenStore
    private let apiClient: APIClient
    private let authService: AuthService

    init(tokenStore: TokenStore = KeychainTokenStore(), apiClient: APIClient = CourtAPIClient(), authService: AuthService = FirebaseAuthService()) {
        self.tokenStore = tokenStore
        self.apiClient = apiClient
        self.authService = authService

        self.accessToken = tokenStore.loadAccessToken()
        self.isAuthenticated = self.accessToken != nil
    }

    func signInWithApple() async {
        await signIn(flow: .apple)
    }

    func signInWithGoogle() async {
        await signIn(flow: .google)
    }

    func signOut() {
        tokenStore.clear()
        accessToken = nil
        currentUser = nil
        authService.signOut()
    }

    private func signIn(flow: AuthProvider) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }

        do {
            print("[AppState] start signIn flow=\(flow)")
            let idToken = try await authService.signIn(provider: flow)
            print("[AppState] got Firebase idToken length=\(idToken.count)")
            let response = try await apiClient.firebaseLogin(idToken: idToken)
            print("[AppState] backend login ok, accessToken length=\(response.accessToken.count)")
            tokenStore.saveAccessToken(response.accessToken)
            await MainActor.run {
                self.accessToken = response.accessToken
                self.currentUser = response.me
                self.isLoading = false
                print("[AppState] set isAuthenticated=\(self.isAuthenticated)")
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.accessToken = "dev_mock_access_token"
                self.currentUser = UserProfile(id: 0, name: "Guest")
                self.isLoading = false
                print("[AppState] backend error; using offline fallback and navigating to Welcome")
            }
        }
    }
}

