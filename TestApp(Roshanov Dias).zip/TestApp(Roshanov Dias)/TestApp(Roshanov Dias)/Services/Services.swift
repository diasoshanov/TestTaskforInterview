//
//  Services.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import Foundation
import Security
import AuthenticationServices
import UIKit
#if canImport(FirebaseAuth)
import FirebaseAuth
#endif
#if canImport(GoogleSignIn)
import GoogleSignIn
#endif
import CryptoKit

// MARK: - Token Storage
protocol TokenStore {
    func saveAccessToken(_ token: String)
    func loadAccessToken() -> String?
    func clear()
}

final class UserDefaultsTokenStore: TokenStore {
    private let key = "access_token"
    
    func saveAccessToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: key)
    }
    
    func loadAccessToken() -> String? {
        return UserDefaults.standard.string(forKey: key)
    }
    
    func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}

// MARK: - API Client (JSON-RPC)
protocol APIClient {
    func firebaseLogin(idToken: String) async throws -> AuthLoginResult
}

struct CourtAPIClient: APIClient {
    private let baseURL = URL(string: "https://api.court360.ai/rpc/client")!

    func firebaseLogin(idToken: String) async throws -> AuthLoginResult {
        var request = URLRequest(url: baseURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "jsonrpc": "2.0",
            "method": "auth.firebaseLogin",
            "params": ["fbIdToken": idToken],
            "id": 1
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }

        struct RPCEnvelope: Decodable {
            let jsonrpc: String
            let result: AuthLoginResult
            let id: Int
        }
        let decoded = try JSONDecoder().decode(RPCEnvelope.self, from: data)
        return decoded.result
    }
}

// MARK: - Auth Service (Firebase placeholders)

protocol AuthService {
    func signIn(provider: AuthProvider) async throws -> String
    func signOut()
}

final class FirebaseAuthService: NSObject, AuthService {
    private var currentNonce: String?

    func signIn(provider: AuthProvider) async throws -> String {
        switch provider {
        case .apple:
            return try await signInWithApple()
        case .google:
            return try await signInWithGoogle()
        }
    }

    func signOut() {
        #if canImport(FirebaseAuth)
        try? Auth.auth().signOut()
        #endif
    }

    // MARK: - Apple
    @MainActor
    private func signInWithApple() async throws -> String {
        #if canImport(FirebaseAuth)
        let nonce = Self.randomNonceString()
        currentNonce = nonce
        let request = ASAuthorizationAppleIDProvider().createRequest()
        request.requestedScopes = [.fullName, .email]
        request.nonce = Self.sha256(nonce)

        let authorization = try await Self.performAppleRequest(requests: [request])
        guard let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential,
              let identityToken = appleIDCredential.identityToken,
              let idTokenString = String(data: identityToken, encoding: .utf8),
              let nonce = currentNonce else {
            throw URLError(.badServerResponse)
        }
        let credential = OAuthProvider.credential(providerID: .apple, idToken: idTokenString, rawNonce: nonce, accessToken: nil)
        return try await Self.firebaseIDToken(from: credential)
        #else
        try await Task.sleep(nanoseconds: 200_000_000)
        return "mock_firebase_id_token"
        #endif
    }

    // MARK: - Google
    @MainActor
    private func signInWithGoogle() async throws -> String {
        #if canImport(FirebaseAuth) && canImport(GoogleSignIn)
        let rootOpt: UIViewController? = await MainActor.run { () -> UIViewController? in
            UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .flatMap { $0.windows }
                .first { $0.isKeyWindow }?.rootViewController
        }
        guard let rootVC = rootOpt else {
            throw URLError(.cannotFindHost)
        }
        let signInResult: GIDSignInResult = try await GIDSignIn.sharedInstance.signIn(withPresenting: rootVC)
        guard let idToken = signInResult.user.idToken?.tokenString else { throw URLError(.badServerResponse) }
        let accessToken = signInResult.user.accessToken.tokenString
        let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
        return try await Self.firebaseIDToken(from: credential)
        #else
        try await Task.sleep(nanoseconds: 200_000_000)
        return "mock_firebase_id_token"
        #endif
    }

    // MARK: - Helpers
    @MainActor
    private static var retainedAppleDelegates: [AppleAuthDelegate] = []
    @MainActor
    private static func performAppleRequest(requests: [ASAuthorizationRequest]) async throws -> ASAuthorization {
        try await withCheckedThrowingContinuation { continuation in
            let controller = ASAuthorizationController(authorizationRequests: requests)
            let delegate = AppleAuthDelegate()
            delegate.completion = { [weak delegate] result in
                if let delegate, let index = retainedAppleDelegates.firstIndex(where: { $0 === delegate }) {
                    retainedAppleDelegates.remove(at: index)
                }
                switch result {
                case .success(let authorization): continuation.resume(returning: authorization)
                case .failure(let error): continuation.resume(throwing: error)
                }
            }
            retainedAppleDelegates.append(delegate)
            controller.delegate = delegate
            controller.presentationContextProvider = delegate
            controller.performRequests()
        }
    }

    #if canImport(FirebaseAuth)
    private static func firebaseIDToken(from credential: AuthCredential) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            Auth.auth().signIn(with: credential) { authResult, error in
                if let error = error { continuation.resume(throwing: error); return }
                authResult?.user.getIDToken { token, err in
                    if let err = err { continuation.resume(throwing: err); return }
                    continuation.resume(returning: token ?? "")
                }
            }
        }
    }
    #endif

    private static func randomNonceString(length: Int = 32) -> String {
        precondition(length > 0)
        let charset = Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz-._")
        var result = ""
        var remainingLength = length

        while remainingLength > 0 {
            let random = UInt8.random(in: 0...255)
            if random < charset.count {
                result.append(charset[Int(random % UInt8(charset.count))])
                remainingLength -= 1
            }
        }
        return result
    }

    private static func sha256(_ input: String) -> String {
        let inputData = Data(input.utf8)
        let hashed = SHA256.hash(data: inputData)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }
}

@MainActor
private final class AppleAuthDelegate: NSObject, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    var completion: ((Result<ASAuthorization, Error>) -> Void)?

    override init() {}

    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow } ?? UIWindow()
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        completion?(.success(authorization))
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        completion?(.failure(error))
    }
}

