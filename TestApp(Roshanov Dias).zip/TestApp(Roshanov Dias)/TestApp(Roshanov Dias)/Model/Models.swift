import Foundation

enum AuthProvider {
    case apple
    case google
}

struct UserProfile: Codable, Equatable {
    let id: Int
    let name: String
}

struct AuthLoginResult: Codable, Equatable {
    let accessToken: String
    let me: UserProfile
}

