//
//  WelcomeViewModel.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import Foundation

final class WelcomeViewModel: ObservableObject {
    @Published var userName: String = ""
    let items = [
        "events",
        "events",
        "events",
    ]
    let gridImg = [
        "img1",
        "img2"
    ]
    let image: [ImageModel] = [
        ImageModel(name: "New Popular", image: "image"),
        ImageModel(name: "Mixed Flowers", image: "image2"),
        ImageModel(name: "Thank you", image: "image3"),
        ImageModel(name: "Flowe you", image: "image2"),
        ImageModel(name: "Good flower", image: "image")
    ]

    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
        userName = appState.currentUser?.name ?? ""
    }

    func signOut() {
        appState.signOut()
    }
}

