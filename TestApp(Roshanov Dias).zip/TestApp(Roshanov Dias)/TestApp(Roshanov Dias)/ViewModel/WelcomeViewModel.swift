//
//  WelcomeViewModel.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//

import Foundation

final class WelcomeViewModel: ObservableObject {
    @Published var userName: String = ""

    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
        userName = appState.currentUser?.name ?? ""
    }

    func signOut() {
        appState.signOut()
    }
}

