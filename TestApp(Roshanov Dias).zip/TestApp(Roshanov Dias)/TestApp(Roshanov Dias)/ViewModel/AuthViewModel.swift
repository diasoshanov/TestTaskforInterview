//
//  AuthViewModel.swift
//  TestApp(Roshanov Dias)
//
//  Created by Диас Рошанов on 03.09.2025.
//


import Foundation
import SwiftUI

final class AuthViewModel: ObservableObject {
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
    }

    func signInWithApple() {
        run { await self.appState.signInWithApple() }
    }

    func signInWithGoogle() {
        run { await self.appState.signInWithGoogle() }
    }

    private func run(_ action: @escaping () async -> Void) {
        errorMessage = nil
        isLoading = true
        Task { @MainActor in
            await action()
            self.errorMessage = self.appState.errorMessage
            self.isLoading = self.appState.isLoading
        }
    }
}


